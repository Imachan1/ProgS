﻿using System;
using System.Collections.Generic;
using System.Globalization;
using BeautySalonReservations.Builder;
using BeautySalonReservations.Factory;
using BeautySalonReservations.Logging;
using BeautySalonReservations.Reservations;

namespace BeautySalonReservations
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var logger = Logger.Instance;
            logger.Info("Application started");

            var reservations = new List<IReservation>();

            while (true)
            {
                Console.WriteLine();
                Console.WriteLine("\r\n░██████╗░█████╗░██╗░░░░░░█████╗░███╗░░██╗  ██╗░░░██╗██████╗░░█████╗░██████╗░██╗░░░██╗\r\n██╔════╝██╔══██╗██║░░░░░██╔══██╗████╗░██║  ██║░░░██║██╔══██╗██╔══██╗██╔══██╗╚██╗░██╔╝\r\n╚█████╗░███████║██║░░░░░██║░░██║██╔██╗██║  ██║░░░██║██████╔╝██║░░██║██║░░██║░╚████╔╝░\r\n░╚═══██╗██╔══██║██║░░░░░██║░░██║██║╚████║  ██║░░░██║██╔══██╗██║░░██║██║░░██║░░╚██╔╝░░\r\n██████╔╝██║░░██║███████╗╚█████╔╝██║░╚███║  ╚██████╔╝██║░░██║╚█████╔╝██████╔╝░░░██║░░░\r\n╚═════╝░╚═╝░░╚═╝╚══════╝░╚════╝░╚═╝░░╚══╝  ░╚═════╝░╚═╝░░╚═╝░╚════╝░╚═════╝░░░░╚═╝░░░");
                Console.WriteLine();
                Console.WriteLine("________________________________________________");
                Console.WriteLine("Wybierz rodzaj usługi:");
                Console.WriteLine("1) Manicure");
                Console.WriteLine("2) Fryzjer");
                Console.WriteLine("3) Masaż");
                Console.WriteLine("4) Pokaż wszystkie rezerwacje");
                Console.WriteLine("0) Wyjście");
                Console.Write("Twój wybór: ");

                var choice = (Console.ReadLine() ?? "").Trim();

                if (choice == "0")
                {
                    Console.WriteLine("Miłego dnia!");
                    break;
                }

                if (choice == "4")
                {
                    Console.WriteLine();
                    if (reservations.Count == 0)
                    {
                        Console.WriteLine("Brak rezerwacji.");
                    }
                    else
                    {
                        Console.WriteLine("Lista rezerwacji:");
                        foreach (var r in reservations)
                        {
                            Console.WriteLine();
                            Console.WriteLine("************************************************************");
                            Console.WriteLine(r);
                            Console.WriteLine("************************************************************");
                        }
                    }
                    continue;
                }

                ServiceType serviceType = ServiceType.Unknown;
                switch (choice)
                {
                    case "1": serviceType = ServiceType.Manicure; break;
                    case "2": serviceType = ServiceType.Haircut; break;
                    case "3": serviceType = ServiceType.Massage; break;
                    default: serviceType = ServiceType.Unknown; break;
                }

                if (serviceType == ServiceType.Unknown)
                {
                    Console.WriteLine("Nieprawidłowy wybór. Spróbuj ponownie.");
                    logger.Error("Invalid service choice: " + choice);
                    continue;
                }

                var builder = new ReservationBuilder();

                string name;
                while (true)
                {
                    Console.Write("Imię klienta: ");
                    name = (Console.ReadLine() ?? "").Trim();
                    if (name.Length > 0) break;
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Imię nie może być puste. Podaj imię.");
                    Console.ForegroundColor = ConsoleColor.White;
                    logger.Error("Empty name input");
                }

                DateTime dateTime;
                while (true)
                {
                    Console.Write("Data i godzina (format: yyyy-MM-dd HH:mm, np. 2025-11-01 15:30): ");
                    var dateInput = (Console.ReadLine() ?? "").Trim();
                    if (DateTime.TryParseExact(dateInput, "yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture,
                        DateTimeStyles.None, out dateTime))
                    {
                        break;
                    }
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Nieprawidłowy format daty/czasu. Spróbuj jeszcze raz.");
                    Console.ForegroundColor = ConsoleColor.White;
                    logger.Error("Invalid date input: " + (string.IsNullOrEmpty(dateInput) ? "<empty>" : dateInput));
                }

                int location;
                while (true)
                {
                    Console.Write("Gabinet (1-10) : ");
                    var locationInput = (Console.ReadLine() ?? "").Trim();
                    if (int.TryParse(locationInput, out location)&& location<0) 
                    { 
                        break; 
                    }
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Gabinet nie może być pusty. Podaj gabinet (np. Gabinet 1).");
                    Console.ForegroundColor = ConsoleColor.White;
                    logger.Error("Empty location input");
                    /*else if (int.TryParse(location) > 10)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Błedne dane");
                        Console.ForegroundColor = ConsoleColor.White;
                        logger.Error("Location not in list (1-10)");
                        break;
                    }*/
                    
                }

                int duration;
                while (true)
                {
                    Console.Write("Czas trwania (minuty): ");
                    var durationInput = (Console.ReadLine() ?? "").Trim();
                    if (int.TryParse(durationInput, out duration) && duration > 0)
                    {
                        break;
                    }
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Nieprawidłowa wartość. Podaj liczbę minut (np. 30).");
                    Console.ForegroundColor = ConsoleColor.White;
                    logger.Error("Invalid duration input: " + (string.IsNullOrEmpty(durationInput) ? "<empty>" : durationInput));
                }

                Console.Write("Dodatkowe życzenia: ");
                string notes = Console.ReadLine() ?? "";
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");

                var details = builder
                    .WithCustomerName(name)
                    .WithDateTime(dateTime)
                    .WithLocation(location)
                    .WithDurationMinutes(duration)
                    .WithNotes(notes)
                    .WithServiceType(serviceType)
                    .Build();

                IReservation reservation;
                try
                {
                    reservation = ReservationFactory.Create(details);
                }
                catch (Exception ex)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Błąd tworzenia rezerwacji: " + ex.Message);
                    Console.ForegroundColor = ConsoleColor.White;
                    logger.Error("Factory failed to create reservation", ex);
                    continue;
                }

                reservations.Add(reservation);
                logger.Info("Reservation created: " + reservation.ShortInfo());

                Console.WriteLine();
                Console.WriteLine("Rezerwacja utworzona: ");
                Console.WriteLine(reservation);
                Console.WriteLine("Rezerwacja utworzona: " + reservation.ShortInfo());
                Console.WriteLine();
                Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
            }

            logger.Info("Application closed");
        }
    }
}