﻿using System;
using System.IO;

namespace BeautySalonReservations.Logging
{
    public sealed class Logger
    {
        public static Logger Instance { get; } = new Logger();

        private readonly object _sync = new object();
        private readonly string _logFilePath;

        private Logger()
        {
            _logFilePath = Path.Combine(AppContext.BaseDirectory, "app.log");
        }

        public void Info(string message)
        {
            Write("INFO", message, null);
        }

        public void Error(string message, Exception ex = null)
        {
            Write("ERROR", message, ex);
        }

        private void Write(string level, string message, Exception ex)
        {
            try
            {
                var time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                var line = $"{time} [{level}] {message}";
                if (ex != null)
                {
                    line += " Exception: " + ex.Message;
                }

                 File.AppendAllText(_logFilePath, line + Environment.NewLine);
            }
            catch
            {
            }
        }
    }
}