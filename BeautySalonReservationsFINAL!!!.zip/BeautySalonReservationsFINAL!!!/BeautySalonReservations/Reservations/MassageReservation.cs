﻿using BeautySalonReservations.Builder;

namespace BeautySalonReservations.Reservations
{
    public class MassageReservation : ReservationBase
    {
        public MassageReservation(ReservationDetails details) : base(details) { }
    }
}
