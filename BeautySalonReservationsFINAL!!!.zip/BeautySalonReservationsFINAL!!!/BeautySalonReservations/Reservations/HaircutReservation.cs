﻿using BeautySalonReservations.Builder;

namespace BeautySalonReservations.Reservations
{
    public class HaircutReservation : ReservationBase
    {
        public HaircutReservation(ReservationDetails details) : base(details) { }
    }
}
