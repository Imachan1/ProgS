﻿using BeautySalonReservations.Builder;

namespace BeautySalonReservations.Reservations
{
    public class ManicureReservation : ReservationBase
    {
        public ManicureReservation(ReservationDetails details) : base(details) { }
    }
}
